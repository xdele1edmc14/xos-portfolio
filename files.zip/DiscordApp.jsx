import { useState, useRef } from "react";
import { DISCORD_ICON, PFP_URI } from "../assets.js";

const DiscordApp = ({ darkMode }) => {
  const bg       = darkMode ? "#313338" : "#f2f3f5";
  const bgHeader = darkMode ? "#2b2d31" : "#e3e5e8";
  const bgCard   = darkMode ? "#2b2d31" : "#ffffff";
  const bgIcon   = darkMode ? "#1e1f22" : "#d4d7dc";
  const border   = darkMode ? "border-white/10" : "border-black/10";
  const titleCol = darkMode ? "#ffffff" : "#060607";
  const mutedCol = darkMode ? "#b5bac1" : "#4e5058";
  return (
    <div className="h-full flex flex-col" style={{background:bg}}>
      <div className={`flex items-center gap-3 px-5 py-4 border-b ${border} flex-shrink-0`} style={{background:bgHeader}}>
        <img src={DISCORD_ICON} alt="Discord" className="w-8 h-8 rounded-xl" />
        <div>
          <div className="font-bold text-sm" style={{color:titleCol}}>My Discord</div>
          <div className="text-xs" style={{color:mutedCol}}>Connect with me on Discord</div>
        </div>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center gap-6 p-8">
        <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-[#5865f2] flex-shrink-0">
          <img src={PFP_URI} alt="xDele1ed" className="w-full h-full object-cover" />
        </div>
        <div className="text-center">
          <div className="text-xl font-bold mb-1" style={{color:titleCol}}>xDele1ed</div>
          <div className="text-sm mb-6" style={{color:mutedCol}}>Minecraft Server Developer · Outcraft WarSMP</div>
          <a href="https://discord.gg/placeholder" target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-white font-semibold text-sm transition-opacity hover:opacity-90"
            style={{background:"#5865f2"}}>
            Join My Discord ↗
          </a>
        </div>
        <div className={`w-full max-w-sm rounded-2xl border ${border} p-4`} style={{background:bgCard}}>
          <div className="text-xs uppercase tracking-widest mb-3" style={{color:mutedCol}}>Servers I'm In</div>
          {[{name:"Outcraft WarSMP",members:"12k+",icon:"⚔️"},{name:"Minecraft Dev Hub",members:"8.4k",icon:"⛏️"},{name:"DeadLands SMP",members:"Coming soon",icon:"🔫"}].map(sv => (
            <div key={sv.name} className="flex items-center gap-3 py-2">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center text-base" style={{background:bgIcon}}>{sv.icon}</div>
              <div className="flex-1">
                <div className="text-xs font-medium" style={{color:titleCol}}>{sv.name}</div>
                <div className="text-[10px]" style={{color:mutedCol}}>{sv.members} members</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export { DiscordApp };
